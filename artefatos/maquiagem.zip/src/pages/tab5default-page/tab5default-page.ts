import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-tab5default-page',
  templateUrl: 'tab5default-page.html'
})
export class Tab5DefaultPagePage {

  constructor(public navCtrl: NavController) {
  }
  
}
