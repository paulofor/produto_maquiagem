import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-tab4default-page',
  templateUrl: 'tab4default-page.html'
})
export class Tab4DefaultPagePage {

  constructor(public navCtrl: NavController) {
  }
  
}
